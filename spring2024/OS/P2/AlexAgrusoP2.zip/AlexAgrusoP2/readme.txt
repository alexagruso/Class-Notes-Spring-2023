To compile the program, simply run "make" in the project directly.

Next, to execute the program, run "./match <SEED>", where <SEED> is
any unsigned integer.

For help, run "./match -h".

Sample outputs are provided for seeds 1, 2, 3, 4, and 5.
