To compile, simply use the makefile provided.

To start the server, run "./server <HOSTNAME> <PORT>" with the hostname and port you want to run the server on.
Next, run "./client <HOSTNAME> <PORT>" with the same hostname and port you passed to the server.

If successful, a menu should pop up with options to modify the data.
A small example dataset is provided in "students.txt".
