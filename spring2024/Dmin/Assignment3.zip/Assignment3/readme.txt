Written in C++

To compile, simply run the provided makefile using "make"

To run, enter the command "./kmeans <int> <input file>",
where <int> is the number of partitions and <input file> is the file which
contains your data.

The output is provided in output.txt, and is overwritten each time you run
the program.
