This program simulates a workload of 10,000 processes and calculates various metrics.

To execute the program, run the following commands in the directory:

$ make
$ ./simulator

The program takes two arguments:
./simulator [average arrival time] [average service time]