To compile the getscore program, run the following command:

	gcc getscore.c -o getscore -z execstack

To compile the exploit, run the following command:

	gcc exploit.c -o exploit

Then, simply run the exploit:
	
	./exploit

Enjoy!
